#include "secpage.h"
#include "ui_secpage.h"
#include<QMessageBox>

secpage::secpage(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::secpage)
{
    ui->setupUi(this);
}

secpage::~secpage()
{
    delete ui;
}

void secpage::paintEvent(QPaintEvent *event){
    QPainter painter(this);
    QPixmap pixmap(":/background1.png");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
}
