#ifndef SECPAGE_H
#define SECPAGE_H

#include <QWidget>
#include<QPainter>
#include<QWidget>
#include<QPixmap>
#include<QPaintEvent>
#include<QPushButton>


namespace Ui {
class secpage;
}

class secpage : public QWidget
{
    Q_OBJECT

public:
    explicit secpage(QWidget *parent = nullptr);
    ~secpage();
    void paintEvent(QPaintEvent*);


private:
    Ui::secpage *ui;
};

#endif // SECPAGE_H
