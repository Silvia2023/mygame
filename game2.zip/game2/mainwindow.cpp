#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QMessageBox>


MainWindow::MainWindow(QWidget *parent):
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *event){
    QPainter painter(this);
    QPixmap pixmap(":/meun01.png");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
}



void MainWindow::on_pushButton_login_clicked()
{
    QString username = ui->lineEdit_username->text();
    QString password = ui->lineEdit_password->text();

    if(username == "12345"&&password == "12345"){
        secp = new secpage(this);
        secp->show();

    }
    else{
        QMessageBox::information(this,"Login","Username and password is not correct");
    }
}

void MainWindow::on_pushButton_help_clicked()
{
    QMessageBox::information(this,"help","The charcaters are controled by mouse. And the username and plassword are both 12345");
}
