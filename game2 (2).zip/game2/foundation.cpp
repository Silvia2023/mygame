#include "foundation.h"
#include<QSize>
#include<QPainter>
#include<QPixmap>
#include<QPoint>



const QSize foundation::a_fixedSize(40,40);

foundation::foundation(QPoint pos,QString path):a_pos(pos),a_path(path),a_isTower(false)
{


}

bool foundation::IsTower(){
    return a_isTower;
}

void foundation::setTower(bool isTower){
    a_isTower = isTower;

}

QPoint foundation::getCenterPos(){
    QPoint tmp;
    tmp.setX(a_pos.x()+a_fixedSize.width()/2);
    tmp.setY(a_pos.y()+a_fixedSize.height()/2);
    return tmp;
}

QPoint foundation::getPos(){
    return a_pos;
}

bool foundation::WithinPos(QPoint pos)
{
    bool xin = (pos.x()>a_pos.x() && pos.x()<a_pos.x()+a_fixedSize.width());
    bool yin = (pos.y()>a_pos.y() && pos.y()<a_pos.y()+a_fixedSize.height());
    return xin&&yin;
}

void foundation::draw(QPainter *painter) const{
     painter->drawPixmap(a_pos,a_path);
}

