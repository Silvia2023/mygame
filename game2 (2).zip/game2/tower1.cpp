#include "tower1.h"
#include<QPainter>
#include<QPixmap>
#include<QPoint>
#include<QString>
#include"Utility.h"
const QSize Tower1::a_fixedSize(40,40);
Tower1::Tower1(QPoint pos,/*Level1 * game,*/QString pixFileName) : QObject(0),a_pos(pos)/*,a_game (game)*/ ,a_path (pixFileName) ,a_attackRange(100)
{
    a_attacking= false;
    a_damage=10;//攻击力10
    a_fireRate = 1000;//1000ms
    a_chooseEnemy=NULL;

    a_fireRateTime=new QTimer(this);
        connect(a_fireRateTime,SIGNAL(timeout()),this,SLOT(shootWeapon()));


}
Tower1::Tower1(){}
Tower1::~Tower1(){
    delete a_fireRateTime;
    a_fireRateTime=NULL;
    a_chooseEnemy=NULL;
    a_game=NULL;
    delete a_chooseEnemy;
}
void Tower1::draw(QPainter *painter)const{
    painter->save();
    painter->setPen(Qt::green);
    painter->drawEllipse(a_pos,a_attackRange,a_attackRange);
    painter->drawPixmap(a_pos.x()-a_fixedSize.width()/2,a_pos.y()-a_fixedSize.height()/2,80,80,a_path);

}
void Tower1::chooseEnemyFromAttack(Enemy *enemy)
{
    a_chooseEnemy=enemy;
    attackEnemy();
    a_chooseEnemy->getAttacked(this);//该敌人受到该防御塔的攻击
}

void Tower1::attackEnemy()
{
    a_fireRateTime->start(a_fireRate);//开始攻击
}

void Tower1::shootWeapon()
{
    Bullet * bullet=new Bullet(a_pos,a_chooseEnemy->getPoint(),a_damage,a_chooseEnemy,a_game);//构造一个子弹，准备攻击敌人
    bullet->move();
    a_game->addBullet(bullet);//将该子弹添加到mainwindow中
}

void Tower1::targetKilled()
{
    if(a_chooseEnemy)
    {
        a_chooseEnemy=NULL;
    }
    a_fireRateTime->stop();//敌人死亡，停止开火
}
void Tower1::lostSightOfEnemy()
{
    a_chooseEnemy->getLostSight(this);
    if(a_chooseEnemy)
    {
        a_chooseEnemy=NULL;
    }
    a_fireRateTime->stop();
}
void Tower1::checkEnemyInRange()
{
    if(a_chooseEnemy)//如果有了攻击的敌人
        {
            QVector2D normalized(a_chooseEnemy->getPoint()-a_pos);
            normalized.normalize();
            if(!collision(a_pos,a_attackRange,a_chooseEnemy->getPoint(),1))//当敌人不在范围内的时候
            {
                lostSightOfEnemy();
            }
        }
        else//如果没有攻击的敌人，就遍历enemylist，找到在攻击范围内的敌人
        {
            QList<Enemy * > a_enemyList=a_game->getEnemyList();
            foreach(Enemy * enemy,a_enemyList)
                if(collision(a_pos,a_attackRange,enemy->getPoint(),1))
                {
                    chooseEnemyFromAttack(enemy);
                    break;
                }
    }
}
Enemy * Tower1::getAttackedEnemy()
{
    return a_chooseEnemy;
}


