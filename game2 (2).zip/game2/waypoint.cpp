#include "waypoint.h"

WayPoint::WayPoint(QPoint pos):a_pos(pos),
    a_nextWayPoint(NULL)
{

}

void WayPoint::setNextWayPoint(WayPoint *nextWaypoint)
{
    a_nextWayPoint = nextWaypoint;
}

WayPoint * WayPoint::getNextWayPoint()
{
    return a_nextWayPoint;
}

const QPoint WayPoint::getPos()
{
    return a_pos;
}

void WayPoint::draw(QPainter *painter) const
{
    painter->save();//
    painter->setPen(Qt::blue);//设置画笔颜色

    painter->drawEllipse(a_pos,4,4);//画一个半径为4的圆，攻击半径

    painter->drawEllipse(a_pos,1,1);//画一个半径为1的圆，显示航点中心点

    if(a_nextWayPoint)//如果存在下一个航点就可以画起来
    {
        painter->drawLine(a_pos,a_nextWayPoint->getPos());
    }

    painter->restore();//恢复原来的画笔设置
}

