#include "level1.h"
#include "ui_level1.h"
#include"mybutton.h"
#include<QPainter>
#include"waypoint.h"
#include"foundation.h"
#include<QPoint>
#include"tower1.h"
#include"Enemy.h"
#include<QTimer>
#include<QString>


class foundation;
Level1::Level1(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Level1)
{
    this->setFixedSize(1500,900);
    ui->setupUi(this);

    addWayPoint1();
    loadTowerFoundation1();

    a_luoboHp =10;
    a_playGold = 1000;

    a_waves=0;
    a_gameWin= false;
    a_gameLose= false;


     QTimer * timer=new QTimer(this);
     connect(timer,SIGNAL(timeout()),this,SLOT(updateMap()));
     timer->start(30);
     QTimer::singleShot(300,this,SLOT(gameStart()));

}

Level1::~Level1()
{
    delete ui;
}
void Level1::paintEvent(QPaintEvent *event){
    QPainter painter(this);
    QPixmap pixmap(":/background4.png");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
    if(a_gameWin||a_gameLose)
    {
        QString text = a_gameLose ? "You Lost":"You Win";
        QPainter painter(this);
        painter.setPen(Qt::red);
        painter.drawText(rect(),Qt::AlignCenter,text);
        return ;
    }


    foreach(Tower1*tower1,a_towerlist)
        tower1->draw(&painter);
    foreach(WayPoint *waypoint,a_waypointList)
      waypoint->draw(&painter);
    foreach(foundation* fpos,a_towerpositionlist)
        fpos->draw(&painter);
    foreach(Enemy* enemy,a_enemylist)
        enemy->draw(&painter);

    foreach(const Bullet * bullet,a_bulletList)
            bullet->draw(&painter);

    drawHp(&painter);
    drawGlod(&painter);
    drawWaves(&painter);

}


void Level1::addWayPoint1(){
    WayPoint * waypoint1 = new WayPoint(QPoint(514,221));
    a_waypointList.push_back(waypoint1);


    WayPoint * waypoint2 = new WayPoint(QPoint(514,438));
    waypoint1->setNextWayPoint(waypoint2);
    a_waypointList.push_back(waypoint2);

    WayPoint * waypoint3 = new WayPoint(QPoint(264,438));//514,221
    waypoint2->setNextWayPoint(waypoint3);
    a_waypointList.push_back(waypoint3);

    WayPoint * waypoint4 = new WayPoint(QPoint(264,695));
    waypoint3->setNextWayPoint(waypoint4);
    a_waypointList.push_back(waypoint4);

    WayPoint * waypoint5 = new WayPoint(QPoint(1244,695));
    waypoint4->setNextWayPoint(waypoint5);
    a_waypointList.push_back(waypoint5);

    WayPoint * waypoint6 = new WayPoint(QPoint(1244,442));
    waypoint5->setNextWayPoint(waypoint6);
    a_waypointList.push_back(waypoint6);

    WayPoint * waypoint7 = new WayPoint(QPoint(1006,442));
    waypoint6->setNextWayPoint(waypoint7);
    a_waypointList.push_back(waypoint7);

    WayPoint * waypoint8 = new WayPoint(QPoint(1006,213));
    waypoint7->setNextWayPoint(waypoint8);
    a_waypointList.push_back(waypoint8);
}

void Level1::loadTowerFoundation1(){

        foundation *  fpos1 = new foundation(QPoint(404,240),":/btnSetTower3.png");
        a_towerpositionlist.push_back(fpos1);
        foundation *  fpos2 = new foundation(QPoint(280,327),":/btnSetTower3.png");
        a_towerpositionlist.push_back(fpos2);
        foundation *  fpos3 = new foundation(QPoint(404,327),":/btnSetTower3.png");
        a_towerpositionlist.push_back(fpos3);
        foundation *  fpos4 = new foundation(QPoint(381,560),":/btnSetTower3.png");
        a_towerpositionlist.push_back(fpos4);
        foundation *  fpos5 = new foundation(QPoint(540,560),":/btnSetTower3.png");
        a_towerpositionlist.push_back(fpos5);
        foundation *  fpos6 = new foundation(QPoint(1100,560),":/btnSetTower3.png");
        a_towerpositionlist.push_back(fpos6);
        foundation *  fpos7 = new foundation(QPoint(900,560),":/btnSetTower3.png");
        a_towerpositionlist.push_back(fpos7);
        foundation *  fpos8 = new foundation(QPoint(1100,325),":/btnSetTower3.png");
        a_towerpositionlist.push_back(fpos8);
        foundation *  fpos9 = new foundation(QPoint(880,300),":/btnSetTower3.png");
        a_towerpositionlist.push_back(fpos9);
        foundation *  fpos10 = new foundation(QPoint(160,550),":/btnSetTower3.png");
        a_towerpositionlist.push_back(fpos10);

}

void Level1::mousePressEvent(QMouseEvent *event){//用鼠标建塔


    int mx = event->x();
    int my = event->y();
    std::cout<<mx<<" "<<my<<std::endl;

    for(int i = 0;i < a_towerpositionlist.size();i++){
        if(!a_towerpositionlist[i]->IsTower()&& event->button()==Qt::LeftButton&&a_towerpositionlist[i]->WithinPos(event->pos())){
            Tower1 * tower1 = new Tower1(a_towerpositionlist[i]->getCenterPos(),":/tower1.png");
            a_playGold -=300;
            a_towerlist.push_back(tower1);
            a_towerpositionlist[i]->setTower(true);
            update();
            break;
        }
    }
}
void Level1::getHpDamage(){
    a_luoboHp -= 1;
}

void Level1::award(){
    a_playGold +=200;
}
void Level1::removeEnemy(Enemy* enemy){
    Q_ASSERT(enemy);
    a_enemylist.removeOne(enemy);
    delete enemy;
    if(a_enemylist.empty())
    {
        ++a_waves;
        if(!loadWaves())
        {
            a_gameWin=true;
        }
    }
}

QList<Enemy*>Level1::getEnemyList(){
    return a_enemylist;
}

QString Level1::getPath(){
    return a_path;
}
bool Level1::loadWaves()
{
    int j = a_waves;
    if(j > 6){
        return false;
    }
    int enemyStartInterval[] = {100,400,600,1000,2500,5000};
    for(int i = 0;i<6;++i)
    {
        WayPoint * startWayPoint;

        startWayPoint=a_waypointList.first();


        Enemy * enemy=new Enemy(startWayPoint,this,":/enemy1.png");
        a_enemylist.push_back(enemy);
        enemy->reSetHp(40+20*(0+a_waves));//波数增加，怪物的血量增加，一次加20点
        QTimer::singleShot(enemyStartInterval[i],enemy,SLOT(doActive()));
    }
    return true;

}

void Level1::gameStart(){
    loadWaves();
}

void Level1::updateMap(){
    foreach(Enemy* enemy1,a_enemylist)
    enemy1->move();
    foreach(Tower1 * tower,a_towerlist)
    tower->checkEnemyInRange();
    update();
}

void Level1::doGameOver()
{
    if(!a_gameLose)
    {
        a_gameLose=true;
    }
}

bool Level1::canBuyTower()
{
    if(a_playGold>=300)
    {
        return true;
    }
    return false;
}

void Level1::drawWaves(QPainter *painter) const
{
    painter->save();
    painter->setPen(Qt::red);
    painter->drawText(QRect(500,5,100,25),QString("WAVES: %1").arg(a_waves+1));
    painter->restore();
}

void Level1::drawHp(QPainter *painter) const
{
    painter->save();
    painter->setPen(Qt::red);
    painter->drawText(QRect(30,5,100,25),QString("HP: %1").arg(a_luoboHp));
    painter->restore();
}

void Level1::drawGlod(QPainter *painter) const
{
    painter->save();
    painter->setPen(Qt::red);
    painter->drawText(QRect(300,5,100,25),QString("GLOD: %1").arg(a_playGold));
}

void Level1::removeBullet(Bullet *bullet)
{
    Q_ASSERT(bullet);
    a_bulletList.removeOne(bullet);

}

void Level1::addBullet(Bullet *bullet)
{
    Q_ASSERT(bullet);
    a_bulletList.push_back(bullet);
}

