#ifndef ENEMY_H
#define ENEMY_H


#include<QObject>
#include<QPoint>
#include<QString>
#include<QPainter>
#include<QSize>

#include"waypoint.h"
#include"level1.h"
#include"tower1.h"

class waypoint;
class Level1;
class Tower1;
class QPainter;

class Enemy:public QObject
{
    Q_OBJECT
public:
    Enemy(WayPoint * startPoint,Level1* game, QString path = ":/enemy1.png");
    ~Enemy();
    void draw(QPainter *painter)const;
    void move();

    QPoint getPoint();//得到敌人当前位置
    void getAttacked(Tower1 * tower);//受到攻击
    void getDamage(int damage);
    void getRemoved();//敌人死亡被移除，血量非正
    void getLostSight(Tower1 *tower);//脱离敌人攻击范围
    void reSetHp(int maxHp);
private slots:
    void doActive();//私有信号槽，敌人是否可以移动

private:
    int a_maxHp;//最大血量
    int a_currentHp;//当前血量
    int a_walkSpeed;//前进速度
    bool a_active;

    WayPoint* a_destinationWayPoint;
    Level1 * _game;
    QPoint a_pos;//当前位置
    QString a_path;//图片路径
    QList<Tower1*>a_attackerTowerlist;//正在攻击敌人的防御塔

    static const QSize a_fixedSize;
};

#endif // ENEMY_H
