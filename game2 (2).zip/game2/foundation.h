#ifndef FOUNDATION_H
#define FOUNDATION_H

#include<QSize>
#include<QPainter>


class foundation
{
public:
    foundation(QPoint pos,QString path = (":/btnSetTower3.png"));//图片路径
    QPoint getCenterPos();//得到防御塔基座的中心点
    QPoint getPos();//得到防御塔基座的左上点

    bool WithinPos(QPoint pos);//判断pos点是否在防御塔基座的范围内

    void draw(QPainter * painter) const ;

    bool IsTower();//是否基座上是否有防御塔

    void setTower(bool isTower = true);


private:
    QPoint a_pos;
    QString a_path;
    bool a_isTower;
    static const QSize a_fixedSize;
    QPoint *_pos;


};

#endif // FOUNDATION_H
