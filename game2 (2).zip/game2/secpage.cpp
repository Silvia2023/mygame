#include "secpage.h"
#include "ui_secpage.h"
#include"mybutton.h"
#include<QMessageBox>
#include"level1.h"

secpage::secpage(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::secpage)
{
    this->setFixedSize(1500,900);
    ui->setupUi(this);
    MyButton *btn = new MyButton(":/meun1.png");
    btn->setParent(this);
    btn->setFixedSize(200,150);
    btn->move(200,100);
    Level1 *scene = new Level1;
    connect(btn,&MyButton::clicked,this,[=](){
        this->hide();
        scene->show();
    });
}

secpage::~secpage()
{
    delete ui;
}

void secpage::paintEvent(QPaintEvent *event){
    QPainter painter(this);
    QPixmap pixmap(":/background02.png");

    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
}
