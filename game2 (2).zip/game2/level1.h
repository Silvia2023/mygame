#ifndef LEVEL1_H
#define LEVEL1_H

#include <QWidget>
#include<QPainter>
#include<QPixmap>
#include<QPaintEvent>
#include<QPushButton>
#include"tower1.h"
#include<QList>
#include"waypoint.h"
#include<QMouseEvent>
#include<iostream>
#include"foundation.h"
#include<QPoint>
#include"Enemy.h"
#include<QString>
#include"bullet.h"


using namespace std;
namespace Ui {
class Level1;
}

class WayPoint;
class Tower1;
class Enemy;
class Bullet;


class Level1 : public QWidget
{
    Q_OBJECT

public:
    explicit Level1(QWidget *parent = nullptr);
    ~Level1();


    void addWayPoint1();//添加航点的函数
    void mousePressEvent(QMouseEvent *event);
    //void mousePressEvent(QMouseEvent *);//
    void loadTowerFoundation1();//加载防御塔基座的函数

    void getHpDamage();//进入萝卜，减一条命
    void award();//敌人死亡，奖励金钱
    void removeEnemy (Enemy* enemy);
    QList<Enemy *>getEnemyList();//
    bool loadWaves();
    QString getPath();

    void removeBullet(Bullet * bullet);
    void addBullet(Bullet * bullet);

    void drawHp(QPainter * painter)const;//画出当前基地血量的信息
    void drawGlod(QPainter * painter)const;//画出当前玩家金钱的信息
    void drawWaves(QPainter * painter)const;//画出当前的波数信息
    bool canBuyTower();

    void doGameOver();





protected:
    void paintEvent(QPaintEvent *);

private:
    Ui::Level1 *ui;

    QList<WayPoint *>a_waypointList;
    QList<foundation *>a_towerpositionlist;
    QList<Tower1*>a_towerlist;

    QList<Enemy*>a_enemylist;
    QList<Bullet *> a_bulletList;//用于存储子弹

    int a_luoboHp;//萝卜的血量
    int a_playGold;//初始金钱
    int a_waves;//敌人的bo'shu
    bool a_gameWin;
    bool a_gameLose;
    QString a_path;

private slots:
    void updateMap();
    void gameStart();
};

#endif // LEVEL1_H
