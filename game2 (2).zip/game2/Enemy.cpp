#include "Enemy.h"
#include "level1.h"
#include "tower1.h"
#include "Utility.h"
#include "waypoint.h"

#include <QPainter>
#include <QPoint>
#include <QSize>
#include <QString>
#include <QVector2D>
#include<QPixmap>

const QSize Enemy::a_fixedSize(45,45);//
Enemy::Enemy(WayPoint * startPoint, Level1*game, QString path):QObject(0),_game(game),a_pos(startPoint->getPos()),a_path(path){
    a_maxHp = 40;
    a_currentHp = a_maxHp;
    a_walkSpeed = 1;
    a_active = false;
    a_destinationWayPoint = startPoint->getNextWayPoint();


}
Enemy::~Enemy(){
    a_attackerTowerlist.clear();
    a_destinationWayPoint = NULL;
    _game = NULL;

}

void Enemy::draw(QPainter *painter) const{
    if(!a_active){
        return ;
    }
    painter->save();
    //绘制敌人的血条
    static const int healthBarWidth=a_fixedSize.width();
    QPoint healthBarPoint=a_pos+QPoint(-a_fixedSize.width()/2,-a_fixedSize.height());
    painter->setPen(Qt::NoPen);//画笔的颜色
    painter->setBrush(Qt::red);//刷子的颜色，填充内部
    QRect healthBarBackRect(healthBarPoint,QSize(healthBarWidth,2));//画出血条
    painter->drawRect(healthBarBackRect);

    painter->setBrush(Qt::green);//敌人被攻击后会扣血，画一个显示敌人当前血量的柱形
    QRect healthBarRect(healthBarPoint,QSize((double)a_currentHp/a_maxHp*healthBarWidth,2));
    painter->drawRect(healthBarRect);//画出当前血量条

    QPoint tmp(a_pos.x()-a_fixedSize.width()/2,a_pos.y()-a_fixedSize.height()/2);
    painter->drawPixmap(tmp.x(),tmp.y(),60,60,a_path);
    painter->restore();

}

void Enemy::move(){
    if(! a_active){
        return ;
    }
    if(collision(a_pos,1,a_destinationWayPoint->getPos(),1)){
        if(a_destinationWayPoint->getNextWayPoint()){
            a_pos = a_destinationWayPoint->getPos();
            a_destinationWayPoint = a_destinationWayPoint->getNextWayPoint();
        }
        else//没有下一个航点
            {
            _game->getHpDamage();
            _game->removeEnemy(this);
            return ;
        }
    }
    else//还没有到目标航点
        {
        QPoint targetPoint=a_destinationWayPoint->getPos();
        double movementSpeed=a_walkSpeed;
        QVector2D normalized(targetPoint-a_pos);
        normalized.normalize();
        a_pos=a_pos+normalized.toPoint()*movementSpeed;
    }
}

void Enemy::doActive(){
    a_active = true;
}
QPoint Enemy::getPoint(){
    return a_pos;
}

void Enemy::getAttacked(Tower1 *tower){
    a_attackerTowerlist.push_back(tower);
}

void Enemy::getDamage(int damage){
    a_currentHp -= damage;
    if (a_currentHp<=0){
        _game->award();
        getRemoved();
    }
}

void Enemy::getRemoved(){
    if(a_attackerTowerlist.empty()){
        return ;
    }
    else{

        foreach(Tower1 * tower,a_attackerTowerlist)
                    tower->targetKilled();
        _game->removeEnemy(this);
    }

}

void Enemy::getLostSight(Tower1 *tower){
    a_attackerTowerlist.removeOne(tower);
}
void Enemy::reSetHp(int maxHp)
{
    a_maxHp=maxHp;
    a_currentHp=maxHp;
}
