#include "bullet.h"

#include "tower1.h"
#include "level1.h"

#include "Enemy.h"

#include <QPoint>
#include <QPainter>
#include <QString>
#include <QPropertyAnimation>

const QSize Bullet::a_fixedSize(8,8);
Bullet::Bullet()
{

}
Bullet::Bullet(QPoint startPos,QPoint targetPos,int damage,Enemy * targetEnemy,Level1 * game,QString path):
    a_startPos(startPos),
    a_targetPos(targetPos),
    a_damage(damage),
    a_path (":/bullet1.png"),
    a_targetEnemy(targetEnemy),
    a_game(game)
{
}
QPoint Bullet::getCurrentPos()
{
    return a_currentPos;
}

void Bullet::setCurrentPos(QPoint pos)
{
    a_currentPos=pos;
}

void Bullet::move()
{
    static int duration=100;//子弹飞行的时间，经过100ms击中敌人
    QPropertyAnimation * animation=new QPropertyAnimation(this,"a_currentPos");
    animation->setDuration(duration);//设置持续时间
    animation->setStartValue(a_startPos);//设置起始位置
    animation->setEndValue(a_targetPos);//设置目标位置
    connect(animation,SIGNAL(finished()),this,SLOT(hitTarget()));//连接信号槽，击中敌人后，子弹动态运动结束
    animation->start();
 }
void Bullet::hitTarget()
{
    if(a_game->getEnemyList().indexOf(a_targetEnemy)!=-1)//如果mainwindow的敌人列表中，有子弹击中的这个敌人，该敌人受到相应的伤害
    {
        a_targetEnemy->getDamage(a_damage);
    }
    a_game->removeBullet(this);//击中敌人后子弹就要消失
}

void Bullet::draw(QPainter *painter) const
{
    painter->drawPixmap(a_currentPos.x(),a_currentPos.y(),8,8,a_path);
}


