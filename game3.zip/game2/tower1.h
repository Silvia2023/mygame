#ifndef TOWER1_H
#define TOWER1_H

#include <QObject>
#include<QPoint>
#include<QPixmap>
class Tower1 : public QObject
{
    Q_OBJECT
public:
    Tower1(QPoint pos,QString pixFileName);
    void draw(QPainter*painter);
private:
    QPoint _pos;
    QPixmap pixmap;

signals:

};

#endif // TOWER1_H
