#include "level1.h"
#include "ui_level1.h"
#include"mybutton.h"
#include<QPainter>


Level1::Level1(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Level1)
{
    this->setFixedSize(1500,900);
    ui->setupUi(this);
    MyButton*setTower = new MyButton(":/btnSetTower1.png");
    setTower->setParent(this);
    setTower->move(900,700);
    connect(setTower,&MyButton::clicked,this,&Level1::set_tower);

}

Level1::~Level1()
{
    delete ui;
}
void Level1::paintEvent(QPaintEvent *event){
    QPainter painter(this);
    QPixmap pixmap(":/background1.png");

    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
    foreach(Tower1*tower1,tower_list)
        tower1->draw(&painter);
}
void Level1::set_tower(){
   Tower1*a_new_tower = new Tower1(QPoint(900,700),":/tower1.png");
   tower_list.push_back(a_new_tower);
   update();
}

