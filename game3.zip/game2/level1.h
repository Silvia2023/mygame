#ifndef LEVEL1_H
#define LEVEL1_H

#include <QWidget>
#include<QPainter>
#include<QPixmap>
#include<QPaintEvent>
#include<QPushButton>
#include"tower1.h"
#include<QList>

namespace Ui {
class Level1;
}

class Level1 : public QWidget
{
    Q_OBJECT

public:
    explicit Level1(QWidget *parent = nullptr);
    ~Level1();
    void paintEvent(QPaintEvent *event);
    void set_tower();

private:
    Ui::Level1 *ui;
    QList<Tower1*>tower_list;
};

#endif // LEVEL1_H
