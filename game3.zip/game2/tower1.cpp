#include "tower1.h"
#include<QPainter>
#include<QPixmap>
#include<QPoint>
Tower1::Tower1(QPoint pos,QString pixFileName) : QObject(0),pixmap(pixFileName)
{
_pos = pos;
}
void Tower1::draw(QPainter *painter){
    painter->drawPixmap(_pos,pixmap);
}
